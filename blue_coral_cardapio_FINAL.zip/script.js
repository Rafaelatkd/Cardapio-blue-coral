
document.querySelectorAll('.filtro-btn').forEach(button => {
  button.addEventListener('click', () => {
    document.querySelectorAll('.filtro-btn').forEach(btn => btn.classList.remove('active'));
    button.classList.add('active');
    const categoria = button.getAttribute('data-categoria');
    document.querySelectorAll('.categoria').forEach(section => {
      section.classList.remove('active');
      if (section.id === categoria) {
        section.classList.add('active');
      }
    });
  });
});
